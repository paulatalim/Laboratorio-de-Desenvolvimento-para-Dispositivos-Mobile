package pucminas.br.sqliteflutter.listsqlite;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
